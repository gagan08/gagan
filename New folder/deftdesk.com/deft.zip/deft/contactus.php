
		<?php include'header.php'?>
		<!--form-starts-->
		
		<div class="form">
		  <div class="container">			
				<div class="row">
				   <div class="col-sx-12 col-sm-8 col-md-8 col-lg-8">
						<h2>Contact Us:</h2>
				   
				   </div>
				    <div class=" col-sx-12 col-sm-4 col-md-4 col-lg-4 ">
						<h4><input  type="text" name="t2" placeholder="Enter Search">
						<input  class="t3" type="submit" value="Search" ></h4>
				   </div>
				
			</div>
		  
		
		      <div class="row">
				   <div class="col-sx-12 col-sm-12 col-md-12 col-lg-12 ">
						<form>
							<table cellspacing="130px">
								<tr>
									
									<td><input class="t1"type="text" name="t1" placeholder="Enter Name" ></td>
								</tr>
								<tr>
									
									<td><input class="t1"type="text" name="t2" placeholder="Enter Email"></td>
								</tr>
								<tr>
									
									<td><input class="t1"type="text" name="t3" placeholder="Contact Number"></td>
								</tr>
								<tr>
									
									<td><input class="t2"type="textarea" name="t3" placeholder="Message"></td>
									
								</tr>
								<tr>
									<td><input class="t3"type="submit" value="SEND" ></td>
			
									
								</tr>
							</table>
						</form>		
					</div>
				</div>	
		  </div>
		</div>
		<!--form-ends-->
		
		<?php include'footer.php'?>