

<?php include'header.php'?>


<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>LOGO DESIGNING</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-1.jpg" ><img src="images/LOGO-1.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-2.png"><img src="images/LOGO-2.png" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-3.png"><img src="images/LOGO-3.png" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-4.png"><img src="images/LOGO-4.png" class="img-project"></a>
							
						</div>
						
						
					</div>
					<br>
					<div class="row">
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-5.jpg" ><img src="images/LOGO-5.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-6.jpg"><img src="images/LOGO-6.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-7.jpg"><img src="images/LOGO-7.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/LOGO-8.png"><img src="images/LOGO-8.png" class="img-project"></a>
							
						</div>
						
						
					</div>
					
				</div>	
			</div><!--end of projects--->	
			
			<?php include'footer.php'?>