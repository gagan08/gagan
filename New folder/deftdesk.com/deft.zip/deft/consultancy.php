

<?php include'header.php'?>


<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>ANDROID</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://www.ameripac-inc.com/" target="_blank"><img src="projects/ameripac.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://www.aviator1909.com/" target="_blank"><img src="projects/aviator.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://www.brainishtutorials.com/" target="_blank"><img src="projects/brainish.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">	
							<a href="http://www.cpasitesolutions.com/" target="_blank"><img src="projects/cpasitesolutions.png" class="img-project"></a>
						</div>
					</div>
					<br>
					<br>
					<div class="row">
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://www.glamourflooring.com/" target="_blank"><img src="projects/glamourflooring.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">	
							<a href="http://www.masatopearls.com/" target="_blank"><img src="projects/masatopearl.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://newcrosslearningcentre.co.uk/" target="_blank"><img src="projects/newcrosslearningcentre.png" class="img-project"></a>
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="http://phplivesupport.com/" target="_blank"><img src="projects/phplivesupport.png" class="img-project"></a>
						</div>
					</div>	
				</div>	
			</div><!--end of projects--->	
			
			<?php include'footer.php'?>