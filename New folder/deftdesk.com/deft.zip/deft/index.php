<?php include'header.php'?>
		<div style="clear:both"></div>
		<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>OUR SERVICES</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2  pic">
							<a href="webdesign.php" target="_blank"><img src="images/web-development.png" class=""></a>
							<a href="webdesign.php" target="_blank"><h4><b>WEB DESIGNING</b></h4></a>
							
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2  pic">
							<a href="logodesign.php" target="_blank"><img src="images/graphics design.png" class=""></a>
							<a href="logodesign.php" target="_blank"><h4><b>GRAPHICS DESIGN</b></h4></a>
						</div>			
						
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2  pic">
							<a href="seo.php" target="_blank"><img src="images/seo11.png" class=""></a>
							<a href="seo.php" target="_blank"><h4><b>SEO</b></h4></a>
						</div>
						
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2  pic">	
							<a href="consultancy.php" target="_blank"><img src="images/Mobile Developement.png" class=""></a>
							<a href="consultancy.php" target="_blank"><h4><b>ANDROID</b></h4></a>
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2  pic">	
							<a href="iphone.php" target="_blank"><img src="images/Mobile Developement.png" class=""></a>
							<a href="iphone.php" target="_blank"><h4><b>IPHONE</b></h4></a>
						</div>
					</div>
					<br>
					<br>
					
			</div><!--end of projects--->		
			<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>OUR CLIENTS</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/compact-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/tv-digital-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/changes-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">	
							<img src="images/finance-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">	
							<img src="images/thousand-logo.jpg" class="img-mgm">
						</div>
					</div>
					<br>
					<br>
					<div class="row">
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/finance-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/thousand-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">
							<img src="images/changes-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">	
							<img src="images/tv-digital-logo.jpg" class="img-mgm">
						</div>
						<div class="col-sx-12 col-sm-2 col-md-2 col-lg-2 image-border">	
							<img src="images/compact-logo.jpg" class="img-mgm">
						</div>
					</div>
				</div>	
			</div><!--end of projects--->	
			<!--munish coding--->
			<div class="support">
		   <div class="container">
				<div class="row">
					<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
						<h2>OUR SUPPORT</h2>
					</div>	
				</div>
			<div class="row">
				<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
					  <div class="support-detail">
							<p>
								In general, technical support services attempt to help the user solve specific problems with a product rather than providing training, customization, or other support services. Most companies offer technical support for the products they sell, either freely available or for a fee. Technical support may be delivered over by e-mail, live support software on a website, or a tool where users can log a call or incident. Larger organizations frequently have internal technical support available to their staff for computer-related problems.
							</p>
						</div>
					</div>	
				</div>
		  </div>	
	   </div><!--end support-->	  
		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
						<h2><strong><center>WE ARE EVERTHING!</center></strong></h2>
					</div>
				</div>	
				<div class="footer-icon">
				 
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<ul class="social">
								<li><img src="images/facebook.png" width="60px" height="60px"></li>
								<li><img src="images/twitter.png" width="60px" height="60px"></li>
								<li><img src="images/linkedin.png" width="60px" height="60px"></li>
								<li><img src="images/youtube.png" width="60px" height="60px"></li>
								<li><img src="images/instagram.png" width="60px" height="60px"></li>
							</ul>	
						</div>
					</div>
							
				</div>	
			</div>	
		</div><!--end of footer-->
		<?php include'footer.php'?>