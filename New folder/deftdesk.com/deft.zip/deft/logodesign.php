

<?php include'header.php'?>


<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>GRAPHICS DESIGN</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-4 col-md-4 col-lg-4 ">
							<a href="psd-design.php" target="_blank"><img src="projects/ameripac.png" class="img-project"></a>
							<a href="psd-design.php" target="_blank"><h4><b>PSD DESIGN</b></h4></a>
						</div>
						
						<div class="col-sx-12 col-sm-4 col-md-4 col-lg-4 ">
							<a href="landin-page.php" target="_blank"><img src="projects/aviator.png" class="img-project"></a>
							<a href="landin-page.php" target="_blank"><h4><b>LANDING PAGE</b></h4></a>
						</div>
						
						<div class="col-sx-12 col-sm-4 col-md-4 col-lg-4 ">
							<a href="logo-design.php" target="_blank"><img src="projects/brainish.png" class="img-project"></a>
							<a href="logo-design.php" target="_blank"><h4><b>LOGO DESIGN</b></h4></a>
						</div>
						
					</div>
					<br>
					
				</div>	
			</div><!--end of projects--->	
			
			<?php include'footer.php'?>