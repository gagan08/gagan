

<?php include'header.php'?>


<div class="projects">
				<div class="container">
					<div class="row">
						<div class="col-sx-12 col-sm-12 col-md-12 col-lg-12">
							<h2><b>PSD DESIGN</b></h2>
						</div>
					</div>	
					<div class="row">
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/PSDDESIGN-1.jpg" ><img src="images/PSDDESIGN-1.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/PSDDESIGN-2.jpg"><img src="images/PSDDESIGN-2.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/PSDDESIGN-3.jpg"><img src="images/PSDDESIGN-3.jpg" class="img-project"></a>
							
						</div>
						<div class="col-sx-12 col-sm-3 col-md-3 col-lg-3  pic">
							<a href="images/PSDDESIGN-4.jpg"><img src="images/PSDDESIGN-4.jpg" class="img-project"></a>
							
						</div>
						
						
					</div>
					<br>
					
				</div>	
			</div><!--end of projects--->	
			
			<?php include'footer.php'?>