<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="font/css/font-awesome.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>DEFTDESK</title>
		
		
		<link href="css/slider.css" rel="stylesheet" type="text/css">

		<link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

		<!-- Get jQuery from CDN -->
		<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
		<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

		<!-- Include the slider scripts -->
		<script type="text/javascript" src="js/transit.js"></script>
		<script type="text/javascript" src="js/touchswipe.js"></script>
		<script type="text/javascript" src="js/jquery.simpleslider.js"></script>
		<script type="text/javascript" src="js/backstretch.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		
		
	</head>
	<body>
	<div class="wrapper">	
		<div class='pagewrap'>			
			<div class='pageblock' id='fullscreen'>
				<div class='slider'>
					<div class='slide' id="first">
						<div class='slidecontent'>
							
							<h1>DEFTDESK</h1>
							<div class="button" onclick="mainslider.nextSlide();">MORE</div>
						</div>
					</div>
					
					<div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 640px; width: 60px; z-index: -999998; position: absolute;">
						<img style="position: absolute; margin: 0px; padding: 0px; border: medium none; height: 640px; max-height: none; max-width: none; z-index: -999999; top: 0px; left: 0px; width: 61px;" src="images/bg1.jpg">
					</div>					
					<div class='slide' id="sec">
						<div class='slidecontent'>
							
							<h1>DEFTDESK</h1>
							<div class="button" onclick="mainslider.nextSlide();">MORE</div>
							
						</div>
					</div>
					<div class='slide' id="thirth">
						<div class='slidecontent'>
							<h1>DEFTDESK</h1>
							<div class="button" onclick="mainslider.nextSlide();">MORE</div>
							
						</div>
					</div>
					<div class='slide' id="fourth">
						<div class='slidecontent'>
							<h1>DEFTDESK</h1>
							<div class="button" onclick="mainslider.nextSlide();">MORE</div>
							
						</div>
					</div>
				</div>
			</div>
		
		</div><!--slider end-->
		<div class="header"><!--header start-->
			<div class="container">
				<div class="row">
					<div class="col-xs-4 col-md-4 col-sm-4 col-lg-4">
						<div class="logo">
							<img class="img-logo" src="images/logo.jpg">
						</div>
					</div>				
					<div class="col-sx-4 col-md-8 col-sm-8 col-lg-8">
						<div class="navigation">
							<ul class="menu">
								<li><a href="index.php">HOME</a></li>
								<li><a href="aboutus.php">ABOUT US</a></li>
								<li><a href="contactus.php">CONTACT US</a></li>
							
							
							</ul>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div><!--header end-->
