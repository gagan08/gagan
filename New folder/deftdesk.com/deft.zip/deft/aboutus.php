<?php include'header.php'?>
<div class="about-us">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						<h2><b>About Us</b></h2>
					</div>	
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<h3><input type="text" name="search" placeholder="search.." class="search"><input type="submit" name="search" value="search" class="search-btn"></h3>
						
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						<p class="about-paragraph">
							<strong>DEFTDESK</strong>
								is a global information technology, consulting and outsourcing company established in 2015.
								<br>
								In
								<strong>DEFTDESK</strong>
								, we help our clients to achieve their business objectives by our deep technology expertise team of professionals. We use best website design and advanced web development techniques to achieve the desired results for our clients.
								<br>
								<strong>DEFTDESK</strong>
								has a closely-knit team of professionals that are experts in their respective fields. The team consists of web designers, web programmers, content writers, search engine optimizers; social media experts along with experienced project managers for a result oriented and streamlined operation.
								<br>
								In today’s world, organizations will have to rapidly reengineer themselves and be more responsive to changing customer needs. So we are always ready for all type of transformations in technology so that we can serve our clients with the best of what technology has to offer.
								<br>
								So if you are looking for going online, we are the one to consult. Please get in touch.
						</p>
					</div>
				</div>
			</div>
		</div><!--end of about us-->		
<?php include'footer.php'?>		
		