<div class="footerup">
			<div class="container">
				<div class="row">
					<div class="col-sx-12 col-md-4 col-lg-4 ">
			
						<h2><strong style="color:#2C2C2C">DEFTDESK</strong></h2>
				
						<p><h4 class="read2">DEFTDESK is a global information technology, consulting and outsourcing company established in 2015. In DEFTDESK, we help our clients to achieve their business objectives by our deep technology expertise team of professionals. We use best website design and advanced web development techniques to achieve the desired results for our clients.</h4></p>
					</div>			
					<div class="col-sx-12  col-md-4 col-lg-4">
						<h2><strong style="color:#2C2C2C">RECENT POST</strong></h2>
					
							<p><h4 class="read2">DEFTDESK is a global information technology consulting.....</h4></p></br>
							<h5><a  class="read" href="#">Read more......</a></h5>
					
					</div>
					<div class="col-sx-12  col-md-4 col-lg-4">
				
						<h2><strong style="color:#2C2C2C">REACH US</h2></strong>
									<h5 style="color:#757575">F 341,Phase 8 B,Industrial Area Mohali,Punjab 160055</h5><br>
														
						  <strong class="read">Phone no.</strong>
							&nbsp;&nbsp;&nbsp;&nbsp;01725097019, 9988088020<br>
						  <strong class="read">Email    							   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>
						  <a class="read" href="http://www.gmail.com">deftdesk@gmail.com</a><br>
						  <strong class="read">Website  </strong>
							<a target="#" class="read" href="www.info@deftdesk.com">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp www.info@deftdesk.com</a>
									
					</div>
				</div>
		</div>
	</div><!-- end of footerup-->	
		
		<div class="footerbottom">
		  <div class="container">
			<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 reserve">
						<span>@2015 DEFTDESK.All Right Reserved.</span>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 design">
						<span>Designed by DEFTDESK.</span> 
					</div>	
		  </div>	
		</div>
		
</div>			


			<!--munish coding--->				
	</div><!--end of wrapper-->
		<script>	
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-45574670-2', 'bitlabsbeta.nl');
		  ga('send', 'pageview');
		</script>
	</body>
</html>